//banner
$(
    function () {
        var imgs=[
            "img/banner/slider-1.jpg",
            "img/banner/slider-2.jpg",
            "img/banner/slider-3.jpg",
            "img/banner/slider-4.jpg",
            "img/banner/slider-5.jpg"
        ];
        var $ulImgs=$("#imgs"),
            LIWIDTH=100,
            $ulIdxs=$("#indexs"),
            moved=0,
            interval=500,
            WAIT=2000+interval,
            timer=null;
        var str="",strIdxs="",i=1;
        for(var src of imgs){
            str+=`<li><img src="${src}"></li>`
            strIdxs+=`<li>${i++}</li>`;
        }
        str+=`<li><img src="${imgs[0]}"></li>`
        $ulImgs.append(str)
               .css("width",(imgs.length+1)*100+'%');
        $ulImgs.children().css("width",100/(imgs.length+1)+'%');
        $ulImgs.children().children().css("width",100+'%').css("height",800)
        $ulIdxs.append(strIdxs)
               .children().first()
               .addClass("hover");
        //启动周期性定时器:
        function play(){
            timer=setInterval(function(){
                moved++;
                $ulImgs.animate({
                    left:-moved*LIWIDTH+'%'
                },
                interval,()=>{//每次移动后判断
                    if(moved==5){//如果移动到最后一张
                        moved=0;//就瞬间返回第一张
                        $ulImgs.css("left",0);
                    }
                    //将$ulIdxs下第moved个li设为hover
                    $ulIdxs.children(":eq("+moved+")")
                           .addClass("hover")
                           .siblings().removeClass("hover");
                })//每次移动耗时0.5秒
            },WAIT);//每隔2.5秒动一次
        }
        play();
        //当鼠标进入slider时
        $("#slider").hover(
            ()=>{
                clearInterval(timer);
                timer=null;
            },
            ()=>play()
        );
        //为$ulIdxs绑定单击事件
        $ulIdxs.on("click","li",e=>{
            var $tar=$(e.target);
            moved=$tar.index();
            $ulImgs.stop(true).animate({
                left:-moved*LIWIDTH+'%'
            },interval,()=>{
                $tar.addClass("hover").siblings().removeClass("hover");
            })
        });
    }
)

//功能模块一:新闻分页查询
//1:发送一个ajax请求 /newslist 获取当前页内容
function loadNews(pageNo) {
    $.ajax({
        type:"GET",
        url:"/newslist",
        data:{pageNo:pageNo},
        success:function(data){
            //console.log(data);
            var html = "";
            for(var i=0;i<data.length;i++){
                var o = data[i];
                html += `
                    <li>
                        <div class="news-time">
                            <h4>${o.pubdate}</h4>
                            <span>${o.pubyear}</span>
                        </div>
                        <div class="news-content">
                            <a href="">
                                <h5>${o.title}</h5>
                            </a>
                            <p>${o.content}</p>
                        </div>
                    </li>`;
            }
            $(".news-list").html(html);
        }
    });
//2:再次发送ajax请求 /newspage 总页数
    $.ajax({
        type:"GET",
        url:"/newspage",
        success:function(data){
            var p = data.page;
            var html = "";
            for(var i=1;i<=data.page;i++){
                if(i==pageNo){
                    html += `<li class="active"><a href="#">${i}</a></li>`;
                }else{
                    html += `<li><a href="#">${i}</a></li>`;
                }
            }
            $(".page-change ol").html(html);
        }
    });
}
loadNews(1);
//3：为页码添加点击功能(分页显示)
$(".page-change ol").on("click","li a",function(e){
    e.preventDefault();
    var pno = parseInt($(this).html());
    loadNews(pno);
});

//功能模块二：登录
$("#userLogin").click(function(){
    $(this).parent().next().css("display","block");
})
$("#bt-cancel").click(function(){
    $(this).parent().parent().parent().parent().hide();
})
$("#bt-login").click(function(){
    var u = $("#uname").val();
    var p = $("#upwd").val();
    $.ajax({
        type:"POST",
        url:"/user_login",
        data:{uname:u,upwd:p},
        success:function(data){
            if(data.code>0){
                console.log("登录成功");
                //隐藏模态框
                $(".modal").hide();
                sessionStorage.setItem("uname",u);
                sessionStorage.setItem("uid",data.uid);
            $("#login-box").hide();
            $("#welcome-box").show();
            }else{
                $("p.alert").html(data.msg);
            }
        },
        error:function(){
            alert("登陆成功");
        }
    });
});